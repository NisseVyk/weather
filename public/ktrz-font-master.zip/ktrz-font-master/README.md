# KTRZ Font

[__The Brand Site__](https://ixkaito.github.io/ktrz-font/)

KTRZ is a free minimal geometric font family. It has 2 styles. The primary style consists of only straight lines and angles of 45 and 90 degrees. The alternative style consists of only straight lines, angles of 45 and 90 degrees and perfect circles. Great for typography, symbols, decorations, backgrounds, minimal designs and fancy stuff.

__Free for both personal & commercial use!__

## Glyphs

![KTRZ](https://user-images.githubusercontent.com/5457539/90873416-1c465080-e3d9-11ea-9c7a-6c07832d5f3f.png)

### KTRZ Alternates

![KTRZ Alternates](https://user-images.githubusercontent.com/5457539/90873426-1ea8aa80-e3d9-11ea-93f6-b324329d9f11.png)

## License

[Apache License 2.0](https://github.com/ixkaito/KTRZ/blob/master/LICENSE)

## Copyright

2020 Kite
